# Red-Submarine
 
Progetto creato tramite la libreria WebGL comprendendo linguaggi HTML5, CSS, linguaggi JavaScript e GLSL, da utilizzare su browser Chrome. Realizzato per l'esame di Computer Graphics a.a. 2023/2024.

Il progetto prevede lo sviluppo di un minigioco 3D all'interno del quale muovere un sottomarino per la ricerca di un tesoro nascosto.

È possibile giocare anche online su [ariarru.github.io](https://ariarru.github.io/Red-Submarine/proj/index.html).
